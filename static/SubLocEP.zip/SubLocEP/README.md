#SubLocEP

SubLocEP is a novel ensemble predictor of subcellular localization of eukaryotic mRNA based on machine learning.

# Dependency

-python3

#content

-our model: data of subcellular localization of eukaryotic mRNA sequence for model training
-sequence-based feature: PseEIIP, TNC, DNC, CKSNAP.
-Physicochemical properties feature: PCPseDNC, PseTNC, SCPseDNC, SCPseTNC, DACC.
-result: The document provides predictive score and labels of single feature classifiers and two-layer integrated model for each sample.

#usage

1.Please unzip pseInOne.tar.gz

predict subcellular localization of eukaryotic mRNA sequences

The script SubLocEP.py is used to predict given sequence. 


The required arguments

-infa a fasta file for test samples

This script ouput the prediction scores for given sequences. 

3.```
python SubLocEP.py -infa input_fa
```




# SubLocEP

The download address of Pse-in-One is http://bioinformatics.hitsz.edu.cn/Pse-in-One2.0/citation/
